# -Javarays-Web-Dev-Finals
## A simple website for our Finals Project in CIT210 - Web Systems and Technologies
We were tasked to create a website with the same layout as what our teacher has provided.

We are only allowed to change the content including:
* Images
* Fonts
* Theme
